# ReactAutoComplete
ReactJs Autocomplete suggestion for text box using Bing API

#Install Packages
Run a command "npm i" to install the packages

#Run server
Globally have to install http-server please follow instruction in this link
http://jasonwatmore.com/post/2016/06/22/nodejs-setup-simple-http-server-local-web-server
after that run the these command
  1. npm start - to start the server & site will be upon localhost port 4848
      http://127.0.0.1:4848
  2. npm run watch - to watch the change in the file
  3. npm run build - to get the production build
  4. npm run test:watch - to excute all the test and watch the changes
  
Have to create Bing API key if this one this Key limit is over. have to pass the api in the header.

Bing allow one request per second for trail api. 
