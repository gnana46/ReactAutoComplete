export const BING_APIKEY = '7178da1e375b46a2bfc2e902f060655b';
export const BING_API_URL = 'https://api.cognitive.microsoft.com/bing/v7.0/Suggestions?q=';
